from binance.enums import*
from bot.client import get_client
from logging_config import setup_logging

logger = setup_logging()

client = get_client()

def place_market_order(symbol, side, quantity):
    """
    Place a MARKET order.
    """
    try:
        order = client.futures_create_order(
            symbol= symbol,
            side = side,
            type= ORDER_TYPE_MARKET,
            quantity=quantity
        )
        logger.info(f"Market Order Placed:{order}")
        return order
    except Exception as e:
        logger.error(f"Market Order Failed:{e}")
        return None
    
def place_limit_order(symbol, side, quantity, price):
    """
    Place a LIMIT order.
    """
    try:
        order = client.futures_create_order(
            symbol = symbol,
            side = side,
            type = ORDER_TYPE_LIMIT,
            timeInForce = TIME_IN_FORCE_GTC
        )
        logger.info(f"Limit Order Placed:{order}")
        return order
    except Exception as e:
        logger.error(f"Limit Order Failed:{e}")
        return None
