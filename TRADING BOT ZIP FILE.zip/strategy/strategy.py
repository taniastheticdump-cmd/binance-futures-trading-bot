import logging

logger = logging.getLogger("trading_bot")

def simple_strategy(price):
    """
    Basic trading logic:
    - Buy if price < 40000
    - sell if price > 60000
    - otherwise hold
    """

    if price< 40000:
        decision = "BUY"
    elif price > 60000:
        decision = "SELL"
    else:
        decision = "HOLD"
    
    logger.info(f"strategy decision:{decision} at price{price}")
    return decision