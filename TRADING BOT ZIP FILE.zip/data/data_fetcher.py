import random
import logging

logger = logging.getLogger("trading_bot")

def get_price(symbol):
    price = round(random.uniform(30000, 70000),2)
    logger.info(f"Fetched price for{symbol}: {price}")
    return price