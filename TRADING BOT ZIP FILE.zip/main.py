from bot.orders import place_market_order, place_limit_order
from bot.validators import (validate_side, 
                            validate_order_type, 
                            validate_quantity, 
                            validate_price
)

def main():
    print("=== Binance Futures Testnet Trading Bot ===")

    symbol = input("Enter symbol (eg. BTCUSDT): ").upper()

    try:
        side = validate_side(input("Enter side(BUY/SELL):"))
        order_type = validate_order_type(input("Enter order type(MARKET/LIMIT):"))
        quantity = validate_quantity(input("Enter Quantity:"))

        if order_type =="MARKET":
            order = place_market_order(symbol, side, quantity)
        else:
            price = validate_price(input("Enter Limit Price:"))
            order= place_limit_order(symbol,side,quantity,price)
        if order:
            print("\n Order Placed Successfully!")
            print(f"Order ID: {order['orderId']}")
            print(f"Symbol: {order['symbol']}")
            print(f"Side: {order['side']}")
            print(f"Type: {order['type']}")
            print(f"Status: {order['status']}")
        else:
            print("\n Order Placement Failed!")
    except Exception as e:
        print(f"\nError: {e}")

if __name__ == "__main__":
    main()


